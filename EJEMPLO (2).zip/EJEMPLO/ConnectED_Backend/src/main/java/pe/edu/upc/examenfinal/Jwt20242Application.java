package pe.edu.upc.examenfinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jwt20242Application {

    public static void main(String[] args) {
        SpringApplication.run(Jwt20242Application.class, args);
    }

}
