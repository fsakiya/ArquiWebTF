package pe.edu.upc.examenfinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jwt20242ApplicationTests {

    @Test
    void contextLoads() {
    }

}
