package com.ecominds.tf_arquiweb.dto;

import lombok.Data;

@Data
public class RecompensaDTO {
    private Integer id;
    private String descripcion;
    private String requisito;
}