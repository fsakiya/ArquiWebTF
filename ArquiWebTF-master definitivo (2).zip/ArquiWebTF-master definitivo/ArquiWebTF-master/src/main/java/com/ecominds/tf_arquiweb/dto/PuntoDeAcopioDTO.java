package com.ecominds.tf_arquiweb.dto;

import lombok.Data;

@Data
public class PuntoDeAcopioDTO {
    private Integer id;
    private String nombre;
    private String ubicacion;
}