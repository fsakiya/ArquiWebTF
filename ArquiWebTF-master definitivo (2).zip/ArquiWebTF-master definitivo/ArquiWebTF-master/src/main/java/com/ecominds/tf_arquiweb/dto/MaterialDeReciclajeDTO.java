package com.ecominds.tf_arquiweb.dto;

import lombok.Data;

@Data
public class MaterialDeReciclajeDTO {
    private Integer id;
    private String nombre;
    private String descripcion;
}
