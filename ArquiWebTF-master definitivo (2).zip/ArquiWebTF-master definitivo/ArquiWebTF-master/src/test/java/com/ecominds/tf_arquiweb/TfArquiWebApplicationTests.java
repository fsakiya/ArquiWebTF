package com.ecominds.tf_arquiweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TfArquiWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
