"# ?? EcoMinds - Plataforma de Reciclaje" 
