package com.ecominds.tf_arquiweb.dto;

import lombok.Data;

@Data
public class OrganizadorDTO {
    private Integer id;
    private String nombre;
}